from marshmallow import Schema, fields

class ShowSchema(Schema):

    id =fields.Int(dump_only=True)
    venue_id =fields.Int(dump_only=True)
    artist_id = fields.Int(dump_only=True)
    start_time = fields.DateTime(dump_only=True)


class VenueSchema(Schema):

    id = fields.Int(dump_only=True)
    name = fields.Str(dump_only=True)
    city = fields.Str(dump_only=True)
    state = fields.Str(dump_only=True)
    genres= fields.List(fields.String(), dump_only=True)
    address = fields.Str(dump_only=True)
    phone = fields.Str(dump_only=True)
    image_link = fields.Str(dump_only=True)
    facebook_link = fields.Str(dump_only=True)
     # migrate
    website = fields.Str(dump_only=True)
    seeking_talent = fields.Bool(dump_only=True)
    seeking_description = fields.Str(dump_only=True)
    shows= fields.Nested(ShowSchema, many=True)
